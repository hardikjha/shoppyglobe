import React from 'react';
import ProductList from '../components/ProductList';
export default function Home() {
  return <main style={{padding:20}}><ProductList /></main>;
}
